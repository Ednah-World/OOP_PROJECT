public interface Statistics {

    void calculateStatistics();

}
