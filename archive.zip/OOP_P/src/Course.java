public class Course {
    private String course_id;
    private String course_name;
    private String credits;
    private String instructor;

    public Course (){
        this.course_id = course_id;
        this.course_name = course_name;
        this.credits = credits;
        this.instructor = instructor;
    }


}
